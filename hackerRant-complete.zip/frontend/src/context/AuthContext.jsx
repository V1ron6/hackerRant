/**
 * Auth Context
 * Cookie-based auth bootstrap via GET /auth/me (see API_DOCS.md).
 */

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authService, clearSessionHint, hasSessionHint } from '../services/api';
import { closeSocket } from '../services/socket';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    // Never signed in on this browser: nothing to restore, skip the probe.
    if (!hasSessionHint()) {
      setUser(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const res = await authService.getMe();
      if (res?.success) {
        setUser(res.data);
      } else {
        setUser(null);
      }
    } catch (err) {
      // 401 = not authenticated
      if (err?.status === 401) clearSessionHint();
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await authService.logout();
    } finally {
      clearSessionHint();
      closeSocket();
      setUser(null);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const value = useMemo(
    () => ({
      user,
      setUser,
      isAuthenticated: !!user,
      loading,
      refresh,
      logout,
    }),
    [user, loading, refresh, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
